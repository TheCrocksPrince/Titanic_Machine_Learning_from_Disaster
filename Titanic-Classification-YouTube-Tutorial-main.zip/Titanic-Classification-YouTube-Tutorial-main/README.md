# Titanic-Classification-YouTube-Tutorial

Ini merupakan dokumentasi tutorial YouTube Titanic Classification, ini merupakan salah satu project Data Scientist atau Data Analyst yang baru untuk pemula untuk mengetahui proses dari awal hingga akhir bagaimana Pengolahan Data bekerja. 

Data Engineer
Data Analyst
Data Science

Langsung check Youtube nya https://www.youtube.com/watch?v=MBvtWlNzOF8&list=PLDMiUlv2m2BPLufkfhrV0B1oiV0x4RQsk 


Let's Connect:

📸 Instagram - https://www.instagram.com/halotech.in/ 

🎥 TikTok - https://www.tiktok.com/@halotechin
